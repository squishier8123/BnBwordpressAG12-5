import { ChevronRight } from 'lucide-react';

const topCounties = [
  { name: 'Pike County', vendors: 23, premium: true },
  { name: 'Adams County', vendors: 19, premium: true },
  { name: 'Fulton County', vendors: 17, premium: true },
  { name: 'Brown County', vendors: 14, premium: false },
  { name: 'Schuyler County', vendors: 12, premium: false },
  { name: 'McDonough County', vendors: 11, premium: false },
  { name: 'Hancock County', vendors: 10, premium: false },
  { name: 'Henderson County', vendors: 9, premium: false },
  { name: 'Knox County', vendors: 8, premium: false },
  { name: 'Warren County', vendors: 7, premium: false },
  { name: 'Peoria County', vendors: 6, premium: false },
  { name: 'Mason County', vendors: 5, premium: false }
];

export function CountyBrowse() {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-[#333D29] mb-3">Browse by County</h2>
          <p className="text-gray-600">Find outfitters, lodging, and services in your target hunting area</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {topCounties.map((county, index) => (
            <button
              key={index}
              className="group bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border border-gray-100 text-left"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="text-[#333D29] mb-1">{county.name}</h4>
                  <p className="text-gray-500 text-sm">{county.vendors} vendors</p>
                </div>
                <ChevronRight className="w-5 h-5 text-[#656D4A] group-hover:translate-x-1 transition-transform" />
              </div>
              {county.premium && (
                <div className="inline-block bg-[#936639]/10 text-[#936639] px-2 py-1 rounded text-xs">
                  Premium Area
                </div>
              )}
            </button>
          ))}
        </div>

        <div className="text-center mt-8">
          <button className="text-[#656D4A] hover:text-[#414833] transition-colors">
            View All 102 Illinois Counties →
          </button>
        </div>
      </div>
    </div>
  );
}
