import { Check, X } from 'lucide-react';

interface PricingTier {
  name: string;
  price: string;
  description: string;
  features: { name: string; included: boolean }[];
  cta: string;
  highlighted: boolean;
}

const tiers: PricingTier[] = [
  {
    name: 'Free',
    price: '$0',
    description: 'Perfect for individual sellers',
    features: [
      { name: 'Up to 3 photos per listing', included: true },
      { name: 'Basic listing visibility', included: true },
      { name: 'Contact form access', included: true },
      { name: 'Featured placement', included: false },
      { name: 'Priority map display', included: false },
      { name: 'Verified badge', included: false }
    ],
    cta: 'Start Free',
    highlighted: false
  },
  {
    name: 'Pro',
    price: '$49',
    description: 'For professional vendors',
    features: [
      { name: 'Up to 15 photos per listing', included: true },
      { name: 'Enhanced visibility', included: true },
      { name: 'Direct contact info display', included: true },
      { name: 'Featured placement rotation', included: true },
      { name: 'Priority map display', included: true },
      { name: 'Verified badge', included: true }
    ],
    cta: 'Go Pro',
    highlighted: true
  },
  {
    name: 'Featured',
    price: '$99',
    description: 'Maximum exposure for outfitters',
    features: [
      { name: 'Unlimited photos', included: true },
      { name: 'Top-tier visibility', included: true },
      { name: 'Featured homepage placement', included: true },
      { name: 'Permanent featured badge', included: true },
      { name: 'Top map priority', included: true },
      { name: 'Verified + Featured badges', included: true }
    ],
    cta: 'Get Featured',
    highlighted: false
  }
];

export function PricingSection() {
  return (
    <div className="bg-gradient-to-br from-[#333D29] to-[#414833] py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-white mb-3">Vendor Pricing</h2>
          <p className="text-white/80">Choose the plan that fits your business</p>
          <p className="text-white/60 text-sm mt-2">Monthly pricing • Cancel anytime</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {tiers.map((tier, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl overflow-hidden ${
                tier.highlighted
                  ? 'ring-4 ring-[#936639] shadow-2xl transform scale-105'
                  : 'shadow-lg'
              }`}
            >
              {tier.highlighted && (
                <div className="bg-[#936639] text-white text-center py-2 text-sm">
                  Most Popular
                </div>
              )}
              
              <div className="p-8">
                <h3 className="text-[#333D29] mb-2">{tier.name}</h3>
                <div className="mb-4">
                  <span className="text-[#333D29]">{tier.price}</span>
                  <span className="text-gray-500">/month</span>
                </div>
                <p className="text-gray-600 mb-6">{tier.description}</p>

                <button
                  className={`w-full py-3 rounded-xl transition-colors mb-8 ${
                    tier.highlighted
                      ? 'bg-[#936639] hover:bg-[#582F0E] text-white'
                      : 'bg-[#656D4A] hover:bg-[#414833] text-white'
                  }`}
                >
                  {tier.cta}
                </button>

                <div className="space-y-3">
                  {tier.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start gap-3">
                      {feature.included ? (
                        <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      ) : (
                        <X className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5" />
                      )}
                      <span
                        className={
                          feature.included ? 'text-gray-700' : 'text-gray-400 line-through'
                        }
                      >
                        {feature.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-white/80">
            Questions about vendor plans?{' '}
            <button className="text-[#A4AC86] hover:text-white transition-colors underline">
              Contact our team
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
