import { X, User, Building2, Package, Briefcase } from 'lucide-react';

interface ListingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ListingModal({ isOpen, onClose }: ListingModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#333D29] to-[#414833] p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <h3 className="text-white mb-2">Create a Listing</h3>
          <p className="text-white/80">Choose your listing type to get started</p>
        </div>

        {/* Content */}
        <div className="p-8">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Individual Seller Option */}
            <button className="group text-left bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl border-2 border-gray-200 hover:border-[#656D4A] transition-all duration-300 hover:shadow-lg">
              <div className="w-16 h-16 bg-gradient-to-br from-[#A4AC86]/20 to-[#656D4A]/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <User className="w-8 h-8 text-[#333D29]" />
              </div>
              <h4 className="text-[#333D29] mb-3">Individual Seller</h4>
              <p className="text-gray-600 mb-4">
                Sell your used hunting gear to local hunters. Quick setup, no fees.
              </p>
              <div className="space-y-2 mb-6">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Package className="w-4 h-4 text-[#656D4A]" />
                  <span>Used gear marketplace</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Package className="w-4 h-4 text-[#656D4A]" />
                  <span>Free to list</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Package className="w-4 h-4 text-[#656D4A]" />
                  <span>Connect with buyers</span>
                </div>
              </div>
              <div className="bg-[#656D4A] text-white px-4 py-2 rounded-lg text-center group-hover:bg-[#414833] transition-colors">
                List Used Gear
              </div>
            </button>

            {/* Vendor/Business Option */}
            <button className="group text-left bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl border-2 border-gray-200 hover:border-[#936639] transition-all duration-300 hover:shadow-lg">
              <div className="w-16 h-16 bg-gradient-to-br from-[#936639]/20 to-[#582F0E]/20 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Building2 className="w-8 h-8 text-[#936639]" />
              </div>
              <h4 className="text-[#333D29] mb-3">Vendor / Business</h4>
              <p className="text-gray-600 mb-4">
                Join our directory as an outfitter, shop, or service provider.
              </p>
              <div className="space-y-2 mb-6">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Briefcase className="w-4 h-4 text-[#936639]" />
                  <span>Directory placement</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Briefcase className="w-4 h-4 text-[#936639]" />
                  <span>Map visibility</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Briefcase className="w-4 h-4 text-[#936639]" />
                  <span>Premium features available</span>
                </div>
              </div>
              <div className="bg-[#936639] text-white px-4 py-2 rounded-lg text-center group-hover:bg-[#582F0E] transition-colors">
                Become a Vendor
              </div>
            </button>
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-500 text-sm">
              Already have an account?{' '}
              <button className="text-[#656D4A] hover:text-[#414833] transition-colors">
                Sign in
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
