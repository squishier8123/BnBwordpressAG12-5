export function Footer() {
  const footerLinks = {
    'About': ['Our Story', 'Contact Us', 'Whitetail-Only Platform', 'Partner With Us'],
    'Resources': ['County Directory', 'Vendor Login', 'Individual Login', 'Pricing Plans'],
    'Popular Counties': ['Pike County', 'Adams County', 'Fulton County', 'Brown County'],
    'Legal': ['Terms of Service', 'Privacy Policy', 'Cookie Policy', 'Guidelines']
  };

  return (
    <footer className="bg-[#333D29] text-white">
      <div className="max-w-[1280px] mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <h4 className="text-white mb-4">Beards & Bucks</h4>
            <p className="text-white/70 text-sm mb-4">
              Illinois' premier whitetail hunting directory and used gear marketplace.
            </p>
            <div className="inline-block bg-[#936639] text-white px-3 py-1 rounded-lg text-xs">
              Whitetail-Only Platform
            </div>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="text-white mb-4 text-sm">{title}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <button className="text-white/70 hover:text-white transition-colors text-sm">
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/60 text-sm">
              © 2025 Beards & Bucks. All rights reserved.
            </p>
            <div className="flex gap-6">
              <button className="text-white/60 hover:text-white transition-colors text-sm">
                Facebook
              </button>
              <button className="text-white/60 hover:text-white transition-colors text-sm">
                Instagram
              </button>
              <button className="text-white/60 hover:text-white transition-colors text-sm">
                YouTube
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
