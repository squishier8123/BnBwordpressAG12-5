import { Home, Compass, Target, Award, Wrench, MapPin, Tent, Sparkles } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  icon: React.ReactNode;
  count: number;
}

const categories: Category[] = [
  { id: '1', name: 'Outfitters', icon: <Compass className="w-8 h-8" />, count: 47 },
  { id: '2', name: 'Lodging', icon: <Home className="w-8 h-8" />, count: 32 },
  { id: '3', name: 'Archery Shops', icon: <Target className="w-8 h-8" />, count: 28 },
  { id: '4', name: 'Taxidermy', icon: <Award className="w-8 h-8" />, count: 19 },
  { id: '5', name: 'Gear Tuning & Service', icon: <Wrench className="w-8 h-8" />, count: 24 },
  { id: '6', name: 'Land Access / Leases', icon: <MapPin className="w-8 h-8" />, count: 15 },
  { id: '7', name: 'Whitetail Experiences', icon: <Tent className="w-8 h-8" />, count: 12 },
  { id: '8', name: 'Featured Services', icon: <Sparkles className="w-8 h-8" />, count: 8 }
];

export function CategoryGrid() {
  return (
    <div className="bg-gray-50 py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-[#333D29] mb-3">Popular Categories</h2>
          <p className="text-gray-600">Explore our directory of Illinois whitetail hunting resources</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <button
              key={category.id}
              className="group bg-white p-8 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-gray-100"
            >
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-[#656D4A] to-[#414833] rounded-xl flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                  {category.icon}
                </div>
                <div>
                  <h4 className="text-[#333D29] mb-1">{category.name}</h4>
                  <p className="text-gray-500 text-sm">{category.count} listings</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
