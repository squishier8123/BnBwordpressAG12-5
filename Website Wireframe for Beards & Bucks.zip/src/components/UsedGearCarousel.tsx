import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';

interface GearItem {
  id: string;
  title: string;
  price: number;
  condition: 'Like New' | 'Good' | 'Fair';
  image: string;
  location: string;
}

const gearItems: GearItem[] = [
  {
    id: '1',
    title: 'Mathews V3X 29 Compound Bow',
    price: 850,
    condition: 'Like New',
    image: 'https://images.unsplash.com/photo-1634188091931-6cb1aa2752db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxodW50aW5nJTIwYm93JTIwYXJjaGVyeXxlbnwxfHx8fDE3NjUxNDExODN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Cook County'
  },
  {
    id: '2',
    title: 'Vortex Diamondback 10x42 Binoculars',
    price: 185,
    condition: 'Good',
    image: 'https://images.unsplash.com/photo-1708015694119-850b776dee58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxodW50aW5nJTIwYmlub2N1bGFycyUyMGdlYXJ8ZW58MXx8fHwxNzY1MTQxMTgzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Peoria County'
  },
  {
    id: '3',
    title: 'Summit Viper SD Climbing Stand',
    price: 245,
    condition: 'Good',
    image: 'https://images.unsplash.com/photo-1731082627921-77d00a9e5ab7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwdGVudCUyMG91dGRvb3J8ZW58MXx8fHwxNzY1MDQ0MzU4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Pike County'
  },
  {
    id: '4',
    title: 'Sitka Gear Elevated II Set (Large)',
    price: 320,
    condition: 'Like New',
    image: 'https://images.unsplash.com/photo-1712787804991-3d56df809bfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbGxpbm9pcyUyMGZvcmVzdCUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3NjUxNDExODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Adams County'
  },
  {
    id: '5',
    title: 'Hoyt RX-7 Ultra Bow Package',
    price: 925,
    condition: 'Like New',
    image: 'https://images.unsplash.com/photo-1634188091931-6cb1aa2752db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxodW50aW5nJTIwYm93JTIwYXJjaGVyeXxlbnwxfHx8fDE3NjUxNDExODN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Fulton County'
  }
];

export function UsedGearCarousel() {
  const [scrollPosition, setScrollPosition] = useState(0);
  const [activeFilter, setActiveFilter] = useState('All');

  const scroll = (direction: 'left' | 'right') => {
    const container = document.getElementById('gear-scroll');
    if (container) {
      const scrollAmount = direction === 'left' ? -400 : 400;
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const conditionColor = (condition: string) => {
    switch (condition) {
      case 'Like New': return 'bg-green-600';
      case 'Good': return 'bg-blue-600';
      case 'Fair': return 'bg-orange-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <div className="bg-white py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-[#333D29] mb-2">Used Gear Marketplace</h2>
            <p className="text-gray-600">Quality pre-owned hunting gear from Illinois hunters</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => scroll('left')}
              className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex gap-3 mb-6 flex-wrap">
          {['All', 'Bows', 'Tree Stands', 'Optics', 'Clothing', 'Accessories'].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeFilter === filter
                  ? 'bg-[#656D4A] text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Carousel */}
        <div
          id="gear-scroll"
          className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {gearItems.map((item) => (
            <div
              key={item.id}
              className="flex-shrink-0 w-[300px] bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow cursor-pointer snap-start overflow-hidden border border-gray-100"
            >
              <div className="relative h-[240px] bg-gray-200 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <div className={`absolute top-3 right-3 ${conditionColor(item.condition)} text-white px-3 py-1 rounded-full text-sm`}>
                  {item.condition}
                </div>
              </div>
              <div className="p-4">
                <h4 className="text-[#333D29] mb-2 line-clamp-2">{item.title}</h4>
                <p className="text-gray-500 text-sm mb-3">{item.location}</p>
                <div className="flex items-center justify-between">
                  <span className="text-[#936639]">${item.price}</span>
                  <button className="text-[#656D4A] hover:text-[#414833] transition-colors">
                    View Details →
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
