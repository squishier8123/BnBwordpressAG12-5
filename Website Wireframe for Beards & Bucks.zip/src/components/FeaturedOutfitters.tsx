import { Star, MapPin, CheckCircle, Crown } from 'lucide-react';

interface Outfitter {
  id: string;
  name: string;
  county: string;
  image: string;
  rating: number;
  reviewCount: number;
  startingRate: number;
  featured: boolean;
  verified: boolean;
}

const outfitters: Outfitter[] = [
  {
    id: '1',
    name: 'Pike County Trophy Hunts',
    county: 'Pike County',
    image: 'https://images.unsplash.com/photo-1634441213839-ff10f912adc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXN0aWMlMjBjYWJpbiUyMHdvb2RzfGVufDF8fHx8MTc2NTE0MTE4NHww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    reviewCount: 127,
    startingRate: 2500,
    featured: true,
    verified: true
  },
  {
    id: '2',
    name: 'Midwest Whitetail Outfitters',
    county: 'Adams County',
    image: 'https://images.unsplash.com/photo-1712787804991-3d56df809bfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbGxpbm9pcyUyMGZvcmVzdCUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3NjUxNDExODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    reviewCount: 94,
    startingRate: 3200,
    featured: true,
    verified: true
  },
  {
    id: '3',
    name: 'Big Buck Country',
    county: 'Fulton County',
    image: 'https://images.unsplash.com/photo-1634441213839-ff10f912adc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXN0aWMlMjBjYWJpbiUyMHdvb2RzfGVufDF8fHx8MTc2NTE0MTE4NHww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.7,
    reviewCount: 82,
    startingRate: 2800,
    featured: false,
    verified: true
  },
  {
    id: '4',
    name: 'Illinois Archery Adventures',
    county: 'Brown County',
    image: 'https://images.unsplash.com/photo-1712787804991-3d56df809bfd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbGxpbm9pcyUyMGZvcmVzdCUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3NjUxNDExODV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    reviewCount: 56,
    startingRate: 2200,
    featured: false,
    verified: true
  }
];

export function FeaturedOutfitters() {
  return (
    <div className="bg-white py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="mb-12">
          <h2 className="text-[#333D29] mb-3">Featured Outfitters</h2>
          <p className="text-gray-600">Premium guided hunts across Illinois whitetail country</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Map Section */}
          <div className="bg-gradient-to-br from-[#A4AC86]/20 to-[#656D4A]/20 rounded-2xl p-8 flex items-center justify-center border border-[#656D4A]/20">
            <div className="text-center">
              <MapPin className="w-16 h-16 text-[#656D4A] mx-auto mb-4" />
              <h3 className="text-[#333D29] mb-2">Interactive Map</h3>
              <p className="text-gray-600 mb-6">
                Explore outfitters by county location
              </p>
              <div className="space-y-2">
                {['Pike County', 'Adams County', 'Fulton County', 'Brown County'].map((county, index) => (
                  <div key={index} className="flex items-center gap-2 justify-center">
                    <div className="w-3 h-3 bg-[#656D4A] rounded-full" />
                    <span className="text-gray-700">{county}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Outfitter Cards */}
          <div className="space-y-4">
            {outfitters.map((outfitter) => (
              <div
                key={outfitter.id}
                className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-shadow border border-gray-100 overflow-hidden"
              >
                <div className="flex gap-4">
                  <div className="w-32 h-32 flex-shrink-0 bg-gray-200 relative">
                    <img
                      src={outfitter.image}
                      alt={outfitter.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 py-4 pr-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="text-[#333D29] mb-1">{outfitter.name}</h4>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <MapPin className="w-4 h-4" />
                          <span>{outfitter.county}</span>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        {outfitter.featured && (
                          <div className="bg-[#936639] text-white px-2 py-1 rounded-lg text-xs flex items-center gap-1">
                            <Crown className="w-3 h-3" />
                            Featured
                          </div>
                        )}
                        {outfitter.verified && (
                          <div className="bg-green-600 text-white px-2 py-1 rounded-lg text-xs flex items-center gap-1">
                            <CheckCircle className="w-3 h-3" />
                            Verified
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm">{outfitter.rating}</span>
                        <span className="text-gray-500 text-sm">({outfitter.reviewCount})</span>
                      </div>
                      <span className="text-[#936639]">
                        Starting at ${outfitter.startingRate.toLocaleString()}
                      </span>
                    </div>
                    <button className="bg-[#656D4A] hover:bg-[#414833] text-white px-4 py-2 rounded-lg transition-colors text-sm">
                      View Outfitter
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
