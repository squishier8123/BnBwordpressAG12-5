import { Menu, X, User } from 'lucide-react';
import { useState } from 'react';

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-[#656D4A] to-[#414833] rounded-lg flex items-center justify-center text-white">
              B&B
            </div>
            <span className="text-[#333D29]">Beards & Bucks</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <button className="text-gray-700 hover:text-[#656D4A] transition-colors">
              Find Hunts
            </button>
            <button className="text-gray-700 hover:text-[#656D4A] transition-colors">
              Used Gear
            </button>
            <button className="text-gray-700 hover:text-[#656D4A] transition-colors">
              Directory
            </button>
            <button className="text-gray-700 hover:text-[#656D4A] transition-colors">
              Counties
            </button>
            <button className="text-gray-700 hover:text-[#656D4A] transition-colors">
              Pricing
            </button>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-3">
            <button className="flex items-center gap-2 text-gray-700 hover:text-[#656D4A] transition-colors">
              <User className="w-5 h-5" />
              Sign In
            </button>
            <button className="bg-[#656D4A] hover:bg-[#414833] text-white px-4 py-2 rounded-lg transition-colors">
              Become a Vendor
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col gap-4">
              <button className="text-gray-700 hover:text-[#656D4A] transition-colors text-left">
                Find Hunts
              </button>
              <button className="text-gray-700 hover:text-[#656D4A] transition-colors text-left">
                Used Gear
              </button>
              <button className="text-gray-700 hover:text-[#656D4A] transition-colors text-left">
                Directory
              </button>
              <button className="text-gray-700 hover:text-[#656D4A] transition-colors text-left">
                Counties
              </button>
              <button className="text-gray-700 hover:text-[#656D4A] transition-colors text-left">
                Pricing
              </button>
              <div className="pt-4 border-t border-gray-200 flex flex-col gap-3">
                <button className="text-gray-700 hover:text-[#656D4A] transition-colors text-left">
                  Sign In
                </button>
                <button className="bg-[#656D4A] hover:bg-[#414833] text-white px-4 py-2 rounded-lg transition-colors">
                  Become a Vendor
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
