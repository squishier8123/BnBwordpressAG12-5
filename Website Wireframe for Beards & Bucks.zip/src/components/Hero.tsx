import { Search, MapPin, ShoppingBag } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative h-[600px] flex items-center justify-center overflow-hidden">
      {/* Hero Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1700245278034-deeaca247214?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aGl0ZXRhaWwlMjBkZWVyJTIwYnVja3xlbnwxfHx8fDE3NjUxNDExODJ8MA&ixlib=rb-4.1.0&q=80&w=1080')`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-[1280px] w-full mx-auto px-6">
        <div className="max-w-2xl">
          <div className="bg-black/40 backdrop-blur-sm p-8 rounded-2xl border border-white/10">
            <h1 className="text-white mb-4">
              Illinois Whitetail Hunting Hub
            </h1>
            <p className="text-white/90 mb-8 text-xl">
              Book premium hunts, find local outfitters, and buy/sell quality used gear. Your complete Midwest whitetail resource.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <button className="flex items-center gap-2 bg-[#656D4A] hover:bg-[#414833] text-white px-6 py-3 rounded-xl transition-colors">
                <Search className="w-5 h-5" />
                Find Hunts
              </button>
              <button className="flex items-center gap-2 bg-[#936639] hover:bg-[#582F0E] text-white px-6 py-3 rounded-xl transition-colors">
                <ShoppingBag className="w-5 h-5" />
                Browse Used Gear
              </button>
              <button className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-xl transition-colors backdrop-blur-sm border border-white/20">
                <MapPin className="w-5 h-5" />
                Find Local Vendors
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
