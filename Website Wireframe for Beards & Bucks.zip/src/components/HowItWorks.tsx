import { Search, ShoppingBag, Users } from 'lucide-react';

const steps = [
  {
    icon: <Search className="w-12 h-12" />,
    title: 'Book Whitetail Hunts',
    description: 'Browse verified outfitters across Illinois. Compare prices, read reviews, and book your next trophy hunt with confidence.'
  },
  {
    icon: <ShoppingBag className="w-12 h-12" />,
    title: 'Buy/Sell Used Gear',
    description: 'Quality pre-owned hunting equipment from local hunters. List your gear for free and connect with serious buyers.'
  },
  {
    icon: <Users className="w-12 h-12" />,
    title: 'Find Local Pros',
    description: 'Connect with archery shops, taxidermists, land leases, and more. Everything you need for a successful season.'
  }
];

export function HowItWorks() {
  return (
    <div className="bg-white py-16">
      <div className="max-w-[1280px] mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-[#333D29] mb-3">How It Works</h2>
          <p className="text-gray-600">Your complete Illinois whitetail resource in three simple steps</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl border-2 border-gray-100 hover:border-[#656D4A]/30 transition-all duration-300 hover:-translate-y-2"
            >
              {/* Step Number */}
              <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-[#656D4A] to-[#414833] text-white rounded-xl flex items-center justify-center shadow-lg">
                {index + 1}
              </div>

              {/* Icon */}
              <div className="w-20 h-20 bg-gradient-to-br from-[#A4AC86]/20 to-[#656D4A]/20 rounded-2xl flex items-center justify-center text-[#333D29] mb-6 mx-auto">
                {step.icon}
              </div>

              {/* Content */}
              <div className="text-center">
                <h3 className="text-[#333D29] mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
