import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { UsedGearCarousel } from './components/UsedGearCarousel';
import { CategoryGrid } from './components/CategoryGrid';
import { FeaturedOutfitters } from './components/FeaturedOutfitters';
import { CountyBrowse } from './components/CountyBrowse';
import { HowItWorks } from './components/HowItWorks';
import { PricingSection } from './components/PricingSection';
import { Footer } from './components/Footer';
import { FloatingCTA } from './components/FloatingCTA';
import { ListingModal } from './components/ListingModal';

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <UsedGearCarousel />
      <CategoryGrid />
      <FeaturedOutfitters />
      <CountyBrowse />
      <HowItWorks />
      <PricingSection />
      <Footer />
      <FloatingCTA onClick={() => setModalOpen(true)} />
      <ListingModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
}
